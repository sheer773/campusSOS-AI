from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
from datetime import datetime
import random

# ============================================================
# CAMPUSSOS AI - BACKEND
# Python + Flask + SQLite
# ============================================================

app = Flask(__name__)

# Allow frontend to communicate with Flask
CORS(app)

# SQLite database file
DATABASE = "database.db"


# ============================================================
# DATABASE CONNECTION
# ============================================================

def get_db_connection():
    """
    Create a connection to SQLite database.
    """
    connection = sqlite3.connect(DATABASE)

    # Allows us to access columns by name
    connection.row_factory = sqlite3.Row

    return connection


# ============================================================
# CREATE DATABASE TABLES
# ============================================================

def init_database():
    """
    Automatically create database and tables
    when the application starts.
    """

    connection = get_db_connection()
    cursor = connection.cursor()

    # --------------------------------------------------------
    # INCIDENTS TABLE
    # --------------------------------------------------------

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_id TEXT UNIQUE NOT NULL,
            category TEXT NOT NULL,
            location TEXT,
            description TEXT NOT NULL,
            priority TEXT NOT NULL,
            anonymous INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )
    """)

    # --------------------------------------------------------
    # SOS EVENTS TABLE
    # --------------------------------------------------------

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sos_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location TEXT,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    connection.commit()
    connection.close()

    print("Database initialized successfully.")


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def generate_report_id():
    """
    Generate a unique report ID like:
    CS-20481
    """

    connection = get_db_connection()
    cursor = connection.cursor()

    while True:

        number = random.randint(10000, 99999)

        report_id = f"CS-{number}"

        cursor.execute(
            "SELECT id FROM incidents WHERE report_id = ?",
            (report_id,)
        )

        existing = cursor.fetchone()

        if not existing:
            connection.close()
            return report_id


def current_time():
    """
    Return current date and time.
    """

    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================
# HEALTH CHECK
# ============================================================

@app.route("/api/health", methods=["GET"])
def health_check():

    return jsonify({
        "status": "success",
        "message": "CampusSOS backend is running"
    })


# ============================================================
# AI ASSISTANT
# ============================================================

@app.route("/api/ai/chat", methods=["POST"])
def ai_chat():

    data = request.get_json(silent=True)

    if not data or "message" not in data:

        return jsonify({
            "success": False,
            "error": "Message is required"
        }), 400

    message = str(data["message"]).strip()

    if not message:

        return jsonify({
            "success": False,
            "error": "Message cannot be empty"
        }), 400

    text = message.lower()

    # --------------------------------------------------------
    # UNSAFE / DANGER
    # --------------------------------------------------------

    if any(word in text for word in [
        "unsafe",
        "danger",
        "scared",
        "follow",
        "threat"
    ]):

        reply = """
Your safety comes first. Move toward a populated,
well-lit area and avoid isolated paths. I recommend
the Central Student Hub. You can also share your
location with campus security using the SOS controls.
"""

    # --------------------------------------------------------
    # MEDICAL
    # --------------------------------------------------------

    elif any(word in text for word in [
        "injured",
        "injury",
        "hurt",
        "medical",
        "bleeding"
    ]):

        reply = """
This may require immediate medical attention.
Move to a safe location and contact campus medical
services. If the situation is life-threatening,
use Emergency SOS or your designated emergency service.
"""

    # --------------------------------------------------------
    # FIRE
    # --------------------------------------------------------

    elif any(word in text for word in [
        "fire",
        "smoke",
        "burning"
    ]):

        reply = """
Move away from the fire or smoke immediately.
Follow campus emergency signs and use the nearest
safe emergency exit. Avoid elevators. If necessary,
activate Emergency SOS and contact the designated
emergency service.
"""

    # --------------------------------------------------------
    # LOST ID
    # --------------------------------------------------------

    elif any(word in text for word in [
        "lost id",
        "student id",
        "lost student",
        "wallet",
        "id card"
    ]):

        reply = """
For a lost student ID, contact Student Services
or the campus administration office. If you believe
your ID was stolen, submit a security incident report
so campus staff can document the incident.
"""

    # --------------------------------------------------------
    # EMERGENCY / SOS
    # --------------------------------------------------------

    elif any(word in text for word in [
        "emergency",
        "sos",
        "help me",
        "urgent"
    ]):

        reply = """
If you are in immediate danger, move to the safest
nearby location and activate Emergency SOS. The
CampusSOS demo workflow will record the emergency
request and location for the campus response workflow.
For a real life-threatening emergency, use your
designated emergency service.
"""

    # --------------------------------------------------------
    # WEATHER
    # --------------------------------------------------------

    elif any(word in text for word in [
        "weather",
        "rain",
        "storm"
    ]):

        reply = """
Consider using covered routes between campus buildings.
Check the campus alerts page before traveling and avoid
open areas during severe weather.
"""

    # --------------------------------------------------------
    # GENERAL RESPONSE
    # --------------------------------------------------------

    else:

        reply = """
I can help with campus emergencies, incident reporting,
safer routes, campus alerts, medical assistance,
security resources, and general campus safety.

Tell me a little more about your situation so I can
recommend the most appropriate next step.
"""

    return jsonify({
        "success": True,
        "reply": reply.strip()
    })


# ============================================================
# CREATE INCIDENT REPORT
# ============================================================

@app.route("/api/incidents", methods=["POST"])
def create_incident():

    data = request.get_json(silent=True)

    if not data:

        return jsonify({
            "success": False,
            "error": "Invalid request"
        }), 400

    category = str(data.get("category", "Other")).strip()
    location = str(data.get("location", "")).strip()
    description = str(data.get("description", "")).strip()
    priority = str(data.get("priority", "normal")).strip()
    anonymous = bool(data.get("anonymous", False))

    # Description is required
    if not description:

        return jsonify({
            "success": False,
            "error": "Incident description is required"
        }), 400

    # Generate unique report ID
    report_id = generate_report_id()

    created_at = current_time()

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO incidents (
            report_id,
            category,
            location,
            description,
            priority,
            anonymous,
            created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        report_id,
        category,
        location,
        description,
        priority,
        1 if anonymous else 0,
        created_at
    ))

    connection.commit()
    connection.close()

    return jsonify({
        "success": True,
        "message": "Incident submitted successfully",
        "report_id": report_id
    }), 201


# ============================================================
# GET ALL INCIDENTS
# ============================================================

@app.route("/api/incidents", methods=["GET"])
def get_incidents():

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            id,
            report_id,
            category,
            location,
            description,
            priority,
            anonymous,
            created_at
        FROM incidents
        ORDER BY id DESC
    """)

    rows = cursor.fetchall()

    connection.close()

    incidents = []

    for row in rows:

        incidents.append({
            "id": row["id"],
            "report_id": row["report_id"],
            "category": row["category"],
            "location": row["location"],
            "description": row["description"],
            "priority": row["priority"],
            "anonymous": bool(row["anonymous"]),
            "created_at": row["created_at"]
        })

    return jsonify({
        "success": True,
        "incidents": incidents
    })


# ============================================================
# CREATE SOS EVENT
# ============================================================

@app.route("/api/sos", methods=["POST"])
def create_sos():

    data = request.get_json(silent=True)

    if not data:

        return jsonify({
            "success": False,
            "error": "Invalid request"
        }), 400

    location = str(
        data.get("location", "Unknown location")
    ).strip()

    if not location:
        location = "Unknown location"

    status = "active"
    created_at = current_time()

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO sos_events (
            location,
            status,
            created_at
        )
        VALUES (?, ?, ?)
    """, (
        location,
        status,
        created_at
    ))

    connection.commit()
    connection.close()

    return jsonify({
        "success": True,
        "message": "Emergency alert sent",
        "status": "active"
    }), 201


# ============================================================
# GET SOS HISTORY
# ============================================================

@app.route("/api/sos", methods=["GET"])
def get_sos():

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            id,
            location,
            status,
            created_at
        FROM sos_events
        ORDER BY id DESC
    """)

    rows = cursor.fetchall()

    connection.close()

    sos_events = []

    for row in rows:

        sos_events.append({
            "id": row["id"],
            "location": row["location"],
            "status": row["status"],
            "created_at": row["created_at"]
        })

    return jsonify({
        "success": True,
        "sos_events": sos_events
    })


# ============================================================
# CAMPUS ALERTS
# ============================================================

@app.route("/api/alerts", methods=["GET"])
def get_alerts():

    alerts = [

        {
            "id": 1,
            "type": "SECURITY",
            "title": "Security alert near North Gate",
            "description": (
                "Campus security has increased patrols "
                "in the area. Students are advised to use "
                "the Central Student Hub route."
            ),
            "time": "8 min ago",
            "severity": "high"
        },

        {
            "id": 2,
            "type": "WEATHER",
            "title": "Heavy rain expected",
            "description": (
                "Consider using covered routes between "
                "campus buildings."
            ),
            "time": "24 min ago",
            "severity": "medium"
        },

        {
            "id": 3,
            "type": "CAMPUS",
            "title": "Library entrance temporarily closed",
            "description": (
                "Use the east entrance until further notice."
            ),
            "time": "1 hour ago",
            "severity": "medium"
        },

        {
            "id": 4,
            "type": "ANNOUNCEMENT",
            "title": "Safety awareness week",
            "description": (
                "Join campus safety workshops throughout "
                "the week."
            ),
            "time": "Today",
            "severity": "low"
        }

    ]

    return jsonify({
        "success": True,
        "alerts": alerts
    })


# ============================================================
# SAFETY MAP
# ============================================================

@app.route("/api/safety-map", methods=["GET"])
def get_safety_map():

    locations = [

        {
            "id": 1,
            "name": "Campus Security",
            "type": "security",
            "location": "North Administration"
        },

        {
            "id": 2,
            "name": "Medical Center",
            "type": "medical",
            "location": "Central Campus"
        },

        {
            "id": 3,
            "name": "Safe Zone",
            "type": "safe_zone",
            "location": "Central Student Hub"
        },

        {
            "id": 4,
            "name": "Emergency Phone",
            "type": "emergency_phone",
            "location": "North Gate"
        }

    ]

    return jsonify({
        "success": True,
        "locations": locations
    })


# ============================================================
# SAFETY SCORE
# ============================================================

@app.route("/api/safety-score", methods=["GET"])
def get_safety_score():

    return jsonify({
        "success": True,
        "score": 84,
        "safe_zones": 12,
        "security_posts": 8,
        "response": "24/7",
        "ai_guidance": "<3m"
    })


# ============================================================
# LOCATION
# ============================================================

@app.route("/api/location", methods=["POST"])
def receive_location():

    data = request.get_json(silent=True)

    if not data:

        return jsonify({
            "success": False,
            "error": "Invalid request"
        }), 400

    latitude = data.get("latitude")
    longitude = data.get("longitude")

    if latitude is None or longitude is None:

        return jsonify({
            "success": False,
            "error": "Latitude and longitude are required"
        }), 400

    # We intentionally do NOT store the location.
    # This is only a demo endpoint for the hackathon.

    return jsonify({
        "success": True,
        "message": "Location received"
    })


# ============================================================
# ERROR HANDLER - 404
# ============================================================

@app.errorhandler(404)
def not_found(error):

    return jsonify({
        "success": False,
        "error": "API endpoint not found"
    }), 404


# ============================================================
# ERROR HANDLER - 500
# ============================================================

@app.errorhandler(500)
def internal_error(error):

    return jsonify({
        "success": False,
        "error": "Internal server error"
    }), 500


# ============================================================
# START APPLICATION
# ============================================================

if __name__ == "__main__":

    # Create database and tables
    init_database()

    print("--------------------------------------------")
    print("CampusSOS AI Backend")
    print("--------------------------------------------")
    print("Server: http://127.0.0.1:5000")
    print("Health: http://127.0.0.1:5000/api/health")
    print("--------------------------------------------")

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )