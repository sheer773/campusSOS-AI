/* =========================================================
   CAMPUSSOS AI
   FRONTEND + FLASK BACKEND CONNECTION
========================================================= */

const API_BASE_URL = "http://127.0.0.1:5000";

let locationIsShared = false;
let sosCountdownTimer = null;
let sosCountdown = 3;


/* =========================================================
   PAGE NAVIGATION
========================================================= */

const navLinks = document.querySelectorAll(".nav-link");
const pages = document.querySelectorAll(".page");

function showPage(pageName) {

  pages.forEach(page => {
    page.classList.remove("active");
  });

  const target = document.getElementById(pageName);

  if (target) {
    target.classList.add("active");
  }

  navLinks.forEach(link => {

    link.classList.remove("active");

    if (link.dataset.page === pageName) {
      link.classList.add("active");
    }

  });

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

  closeMobileMenu();
}


/* =========================================================
   MOBILE NAVIGATION
========================================================= */

function toggleMobileMenu() {

  const menu = document.getElementById("mobileMenu");

  if (menu) {
    menu.classList.toggle("open");
  }

}


function closeMobileMenu() {

  const menu = document.getElementById("mobileMenu");

  if (menu) {
    menu.classList.remove("open");
  }

}


function mobileNavigate(page) {

  showPage(page);

  closeMobileMenu();

}


/* =========================================================
   NAV LINK EVENTS
========================================================= */

navLinks.forEach(link => {

  link.addEventListener("click", () => {

    const page = link.dataset.page;

    showPage(page);

  });

});


/* =========================================================
   TOAST
========================================================= */

let toastTimeout;

function showToast(message) {

  const toast = document.getElementById("toast");
  const messageElement =
    document.getElementById("toastMessage");

  if (!toast || !messageElement) {
    console.log(message);
    return;
  }

  messageElement.textContent = message;

  toast.classList.add("show");

  clearTimeout(toastTimeout);

  toastTimeout = setTimeout(() => {

    toast.classList.remove("show");

  }, 3000);

}


/* =========================================================
   BACKEND HEALTH CHECK
========================================================= */

async function checkBackend() {

  try {

    const response =
      await fetch(`${API_BASE_URL}/api/health`);

    const data =
      await response.json();

    console.log("Backend:", data);

    if (data.status === "success") {

      console.log(
        "CampusSOS backend connected successfully."
      );

    }

  } catch (error) {

    console.error(
      "Backend connection failed:",
      error
    );

    showToast(
      "Backend is not connected. Start Flask server."
    );

  }

}


/* =========================================================
   LOCATION SHARING
========================================================= */

async function shareLocation() {

  if (!locationIsShared) {

    if (!navigator.geolocation) {

      showToast(
        "Geolocation is not supported by this browser"
      );

      return;

    }


    navigator.geolocation.getCurrentPosition(

      async function(position) {

        const latitude =
          position.coords.latitude;

        const longitude =
          position.coords.longitude;


        try {

          const response =
            await fetch(
              `${API_BASE_URL}/api/location`,
              {
                method: "POST",

                headers: {
                  "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({
                  latitude: latitude,
                  longitude: longitude
                })
              }
            );


          const data =
            await response.json();


          if (!response.ok) {

            throw new Error(
              data.error ||
              "Location request failed"
            );

          }


          locationIsShared = true;


          const action =
            document.getElementById(
              "locationAction"
            );

          if (action) {

            action.textContent =
              "Location Shared";

          }


          showToast(
            "Your location is now being shared"
          );


          console.log(
            "Location sent:",
            data
          );


        } catch (error) {

          console.error(
            "Location API error:",
            error
          );

          showToast(
            "Unable to share location"
          );

        }

      },


      function(error) {

        console.error(
          "Geolocation error:",
          error
        );

        showToast(
          "Please allow location access"
        );

      }

    );

  } else {

    locationIsShared = false;


    const action =
      document.getElementById(
        "locationAction"
      );

    if (action) {

      action.textContent =
        "Share My Location";

    }


    showToast(
      "Location sharing stopped"
    );

  }

}


/* =========================================================
   SOS MODAL
========================================================= */

function openSOS() {

  const modal =
    document.getElementById("sosModal");

  if (!modal) return;

  modal.classList.add("open");

  resetSOS();

}


function closeSOS() {

  const modal =
    document.getElementById("sosModal");

  if (!modal) return;

  modal.classList.remove("open");

  resetSOS();

}


function resetSOS() {

  clearInterval(sosCountdownTimer);

  sosCountdown = 3;


  const initial =
    document.getElementById("sosInitial");

  const active =
    document.getElementById("sosActive");

  const countdown =
    document.getElementById("countdown");

  const activateButton =
    document.getElementById("activateSOS");


  if (initial) {

    initial.style.display =
      "block";

  }


  if (active) {

    active.classList.remove(
      "visible"
    );

  }


  if (countdown) {

    countdown.style.display =
      "none";

    countdown.textContent =
      "3";

  }


  if (activateButton) {

    activateButton.disabled =
      false;

  }

}


/* =========================================================
   ACTIVATE SOS
========================================================= */

function activateSOS() {

  const button =
    document.getElementById(
      "activateSOS"
    );

  const countdown =
    document.getElementById(
      "countdown"
    );


  if (!button || !countdown) {
    return;
  }


  button.disabled = true;

  countdown.style.display =
    "grid";

  sosCountdown = 3;

  countdown.textContent =
    sosCountdown;


  sosCountdownTimer =
    setInterval(() => {

      sosCountdown--;

      countdown.textContent =
        sosCountdown;


      if (sosCountdown <= 0) {

        clearInterval(
          sosCountdownTimer
        );

        activateEmergencyState();

      }

    }, 800);

}


/* =========================================================
   SEND SOS TO BACKEND
========================================================= */

async function sendSOS() {

  let locationText =
    "Central Student Hub";


  try {

    if (
      navigator.geolocation
    ) {

      const position =
        await new Promise(
          (resolve, reject) => {

            navigator.geolocation.getCurrentPosition(
              resolve,
              reject,
              {
                timeout: 3000
              }
            );

          }
        );


      locationText =
        `${position.coords.latitude}, ${position.coords.longitude}`;

    }

  } catch (error) {

    console.log(
      "Location unavailable, using default location."
    );

  }


  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/sos`,
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json"
          },

          body: JSON.stringify({
            location: locationText
          })
        }
      );


    const data =
      await response.json();


    if (!response.ok) {

      throw new Error(
        data.error ||
        "SOS request failed"
      );

    }


    console.log(
      "SOS backend response:",
      data
    );


    return data;


  } catch (error) {

    console.error(
      "SOS API error:",
      error
    );

    showToast(
      "Could not connect to SOS backend"
    );

    return null;

  }

}


/* =========================================================
   ACTIVE EMERGENCY STATE
========================================================= */

async function activateEmergencyState() {

  const initial =
    document.getElementById(
      "sosInitial"
    );

  const active =
    document.getElementById(
      "sosActive"
    );


  if (initial) {

    initial.style.display =
      "none";

  }


  if (active) {

    active.classList.add(
      "visible"
    );

  }


  const result =
    await sendSOS();


  if (result) {

    showToast(
      "Emergency alert sent successfully"
    );

  }

}


/* =========================================================
   AI ASSISTANT
========================================================= */

function handleAIKey(event) {

  if (event.key === "Enter") {

    event.preventDefault();

    sendAI();

  }

}


function askAI(question) {

  const input =
    document.getElementById(
      "aiInput"
    );

  if (!input) return;

  input.value =
    question;

  sendAI();

}


/* =========================================================
   SEND AI MESSAGE TO FLASK
========================================================= */

async function sendAI() {

  const input =
    document.getElementById(
      "aiInput"
    );

  const chat =
    document.getElementById(
      "chatBody"
    );


  if (!input || !chat) {
    return;
  }


  const message =
    input.value.trim();


  if (!message) {

    showToast(
      "Tell the AI what is happening first"
    );

    return;

  }


  /* USER MESSAGE */

  const userRow =
    document.createElement(
      "div"
    );

  userRow.className =
    "chat-row";

  userRow.style.justifyContent =
    "flex-end";


  const userBubble =
    document.createElement(
      "div"
    );

  userBubble.className =
    "chat-bubble";

  userBubble.style.background =
    "#2563eb";

  userBubble.style.color =
    "white";

  userBubble.style.borderRadius =
    "14px 14px 4px 14px";

  userBubble.textContent =
    message;


  userRow.appendChild(
    userBubble
  );

  chat.appendChild(
    userRow
  );


  input.value = "";

  chat.scrollTop =
    chat.scrollHeight;


  /* AI THINKING */

  const thinking =
    document.createElement(
      "div"
    );

  thinking.className =
    "chat-row ai";

  thinking.innerHTML = `
    <div class="chat-avatar">
      <i class="fa-solid fa-robot"></i>
    </div>

    <div class="chat-bubble">
      <i class="fa-solid fa-circle-notch fa-spin"></i>
      Analyzing your situation...
    </div>
  `;


  chat.appendChild(
    thinking
  );

  chat.scrollTop =
    chat.scrollHeight;


  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/ai/chat`,
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json"
          },

          body: JSON.stringify({
            message: message
          })
        }
      );


    const data =
      await response.json();


    thinking.remove();


    if (!response.ok) {

      throw new Error(
        data.error ||
        "AI request failed"
      );

    }


    const reply =
      data.reply ||
      "Sorry, I could not generate a response.";


    addAIMessage(
      chat,
      reply
    );


  } catch (error) {

    console.error(
      "AI API error:",
      error
    );


    thinking.remove();


    addAIMessage(
      chat,
      "I could not connect to the CampusSOS AI backend. Please make sure Flask is running on port 5000."
    );

  }

}


/* =========================================================
   ADD AI MESSAGE
========================================================= */

function addAIMessage(
  chat,
  response
) {

  const aiRow =
    document.createElement(
      "div"
    );

  aiRow.className =
    "chat-row ai";


  const avatar =
    document.createElement(
      "div"
    );

  avatar.className =
    "chat-avatar";

  avatar.innerHTML =
    `<i class="fa-solid fa-robot"></i>`;


  const bubble =
    document.createElement(
      "div"
    );

  bubble.className =
    "chat-bubble";


  const label =
    document.createElement(
      "strong"
    );

  label.style.display =
    "block";

  label.style.color =
    "#2563eb";

  label.style.fontSize =
    "8px";

  label.style.letterSpacing =
    ".12em";

  label.style.marginBottom =
    "5px";

  label.textContent =
    "AI SAFETY GUIDANCE";


  const responseText =
    document.createElement(
      "div"
    );

  responseText.textContent =
    response;


  bubble.appendChild(
    label
  );

  bubble.appendChild(
    responseText
  );


  aiRow.appendChild(
    avatar
  );

  aiRow.appendChild(
    bubble
  );


  chat.appendChild(
    aiRow
  );


  chat.scrollTop =
    chat.scrollHeight;

}


/* =========================================================
   VOICE SOS
========================================================= */

function voiceSOS() {

  showToast(
    "Listening for voice SOS..."
  );


  if (
    "webkitSpeechRecognition" in window ||
    "SpeechRecognition" in window
  ) {

    const SpeechRecognition =
      window.SpeechRecognition ||
      window.webkitSpeechRecognition;


    const recognition =
      new SpeechRecognition();


    recognition.lang =
      "en-US";


    recognition.start();


    recognition.onresult =
      function(event) {

        const result =
          event.results[0][0]
            .transcript;


        const input =
          document.getElementById(
            "aiInput"
          );


        if (input) {

          input.value =
            result;

        }


        showToast(
          "Voice captured"
        );


        if (
          result
            .toLowerCase()
            .includes("sos") ||
          result
            .toLowerCase()
            .includes("emergency")
        ) {

          openSOS();

        }

      };


    recognition.onerror =
      function() {

        showToast(
          "Voice recognition unavailable"
        );

      };

  } else {

    showToast(
      "Voice recognition is not supported in this browser"
    );

  }

}


/* =========================================================
   INCIDENT REPORT
========================================================= */

const incidentForm =
  document.getElementById(
    "incidentForm"
  );


if (incidentForm) {

  incidentForm.addEventListener(
    "submit",
    async function(event) {

      event.preventDefault();


      const description =
        document.getElementById(
          "incidentDescription"
        )?.value.trim();


      if (!description) {

        showToast(
          "Please describe the incident"
        );

        return;

      }


      /* GET FORM VALUES */

      const categoryElement =
        document.querySelector(
          'select[name="category"]'
        );


      const locationElement =
        document.querySelector(
          'input[name="location"]'
        );


      const anonymousElement =
        document.querySelector(
          'input[name="anonymous"]'
        );


      const activePriority =
        document.querySelector(
          ".priority.active"
        );


      const category =
        categoryElement
          ? categoryElement.value
          : "Security";


      const location =
        locationElement
          ? locationElement.value
          : "Campus";


      const anonymous =
        anonymousElement
          ? anonymousElement.checked
          : false;


      let priority =
        "normal";


      if (activePriority) {

        priority =
          activePriority.dataset.priority ||
          activePriority.getAttribute(
            "data-priority"
          ) ||
          "urgent";

      }


      /* SEND TO FLASK */

      try {

        const response =
          await fetch(
            `${API_BASE_URL}/api/incidents`,
            {
              method: "POST",

              headers: {
                "Content-Type":
                  "application/json"
              },

              body: JSON.stringify({

                category:
                  category,

                location:
                  location,

                description:
                  description,

                priority:
                  priority,

                anonymous:
                  anonymous

              })
            }
          );


        const data =
          await response.json();


        if (!response.ok) {

          throw new Error(
            data.error ||
            "Incident submission failed"
          );

        }


        console.log(
          "Incident submitted:",
          data
        );


        const form =
          document.getElementById(
            "incidentForm"
          );


        const success =
          document.getElementById(
            "reportSuccess"
          );


        if (form) {

          form.style.display =
            "none";

        }


        if (success) {

          success.classList.add(
            "visible"
          );

        }


        showToast(
          `Incident submitted: ${data.report_id}`
        );


      } catch (error) {

        console.error(
          "Incident API error:",
          error
        );


        showToast(
          "Could not submit incident. Check Flask backend."
        );

      }

    }
  );

}


/* =========================================================
   RESET REPORT
========================================================= */

function resetReport() {

  const form =
    document.getElementById(
      "incidentForm"
    );

  const success =
    document.getElementById(
      "reportSuccess"
    );


  if (form) {

    form.reset();

    form.style.display =
      "block";

  }


  if (success) {

    success.classList.remove(
      "visible"
    );

  }

}


/* =========================================================
   INCIDENT PRIORITY
========================================================= */

function setPriority(
  button,
  priority
) {

  const buttons =
    document.querySelectorAll(
      ".priority"
    );


  buttons.forEach(btn => {

    btn.classList.remove(
      "active"
    );

  });


  button.classList.add(
    "active"
  );


  button.dataset.priority =
    priority;


  if (priority === "critical") {

    button.style.color =
      "#dc2626";

    button.style.background =
      "#fef2f2";


    showToast(
      "Critical priority selected"
    );


  } else if (priority === "urgent") {

    button.style.color =
      "#d97706";

    button.style.background =
      "#fffbeb";


    showToast(
      "Urgent priority selected"
    );


  } else {

    button.style.color = "";

    button.style.background = "";

  }

}


/* =========================================================
   LOAD SAFETY SCORE
========================================================= */

async function loadSafetyScore() {

  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/safety-score`
      );


    const data =
      await response.json();


    if (!response.ok) {

      throw new Error(
        data.error ||
        "Safety score failed"
      );

    }


    console.log(
      "Safety Score:",
      data
    );


    const score =
      document.querySelector(
        ".score-header strong"
      );


    if (score && data.score !== undefined) {

      score.textContent =
        data.score;

    }


  } catch (error) {

    console.error(
      "Safety score error:",
      error
    );

  }

}


/* =========================================================
   LOAD CAMPUS ALERTS
========================================================= */

async function loadAlerts() {

  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/alerts`
      );


    const data =
      await response.json();


    console.log(
      "Campus Alerts:",
      data
    );


    /*
      Backend is connected successfully.
      If your HTML already has alert cards,
      we don't replace them automatically.
    */


  } catch (error) {

    console.error(
      "Alerts API error:",
      error
    );

  }

}


/* =========================================================
   LOAD SAFETY MAP DATA
========================================================= */

async function loadSafetyMap() {

  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/safety-map`
      );


    const data =
      await response.json();


    console.log(
      "Safety Map:",
      data
    );


  } catch (error) {

    console.error(
      "Safety map API error:",
      error
    );

  }

}


/* =========================================================
   LOAD INCIDENT HISTORY
========================================================= */

async function loadIncidents() {

  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/incidents`
      );


    const data =
      await response.json();


    console.log(
      "Incident History:",
      data
    );


  } catch (error) {

    console.error(
      "Incident history error:",
      error
    );

  }

}


/* =========================================================
   LOAD SOS HISTORY
========================================================= */

async function loadSOSHistory() {

  try {

    const response =
      await fetch(
        `${API_BASE_URL}/api/sos`
      );


    const data =
      await response.json();


    console.log(
      "SOS History:",
      data
    );


  } catch (error) {

    console.error(
      "SOS history error:",
      error
    );

  }

}


/* =========================================================
   ESCAPE KEY
========================================================= */

document.addEventListener(
  "keydown",
  function(event) {

    if (event.key === "Escape") {

      closeSOS();

      closeMobileMenu();

    }

  }
);


/* =========================================================
   CLOSE SOS MODAL OUTSIDE
========================================================= */

const sosModal =
  document.getElementById(
    "sosModal"
  );


if (sosModal) {

  sosModal.addEventListener(
    "click",
    function(event) {

      if (
        event.target === this
      ) {

        closeSOS();

      }

    }
  );

}


/* =========================================================
   SAFETY PULSE
========================================================= */

function updateSafetyPulse() {

  const score =
    document.querySelector(
      ".score-header strong"
    );


  if (!score) return;


  /*
    Use backend safety score
    instead of fake random values.
  */

  loadSafetyScore();

}


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  function() {

    showPage("home");


    /* Backend connection test */

    checkBackend();


    /* Load backend data */

    loadSafetyScore();

    loadAlerts();

    loadSafetyMap();

    loadIncidents();

    loadSOSHistory();


    /* Refresh safety score */

    setInterval(
      updateSafetyPulse,
      8000
    );

  }
);